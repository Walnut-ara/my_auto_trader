#!/usr/bin/env python3
# grid_backtest.py

from walkforward import run_walkforward

if __name__ == "__main__":
    # 전체 그리드 정의 (원하시는 대로 수정 가능)
    param_grid = {
        "rsi_threshold": [10, 20, 30, 40],
        "sl_mult":       [0.5, 1.0, 1.5],
        "tp_mult":       [1.0, 2.0, 3.0],
    }

    # 워크포워드 실행: 이 한 번으로 모든 조합에 대한 CSV가 생성됩니다.
    df = run_walkforward(
        symbol="ADAUSDT",
        start_date="2025-01-01",
        end_date="2025-05-31",
        window=60,
        step=15,
        param_grid=param_grid
    )
    print("✅ Grid backtest complete. Results saved to walkforward_ADAUSDT.csv")

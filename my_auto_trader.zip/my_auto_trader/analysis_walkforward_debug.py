#!/usr/bin/env python3
# analysis_walkforward_debug.py
import os
import pandas as pd
import matplotlib.pyplot as plt

# ── 디버그: 현재 경로 & 파일 목록 출력 ──────────────────────────────
print("▶ Working directory:", os.getcwd())
print("▶ Files here:", os.listdir())
print()

# 1) 워크포워드 결과 로드
csv_name = "walkforward_ADAUSDT.csv"
df = pd.read_csv(csv_name)
print(f"Loaded {csv_name}: {len(df)} rows")

# 2) 요약 통계 출력
summary = {
    "Mean PnL": df["test_pnl"].mean(),
    "Median PnL": df["test_pnl"].median(),
    "Std PnL": df["test_pnl"].std(),
    "Max PnL": df["test_pnl"].max(),
    "Min PnL": df["test_pnl"].min(),
    "Win Rate": (df["test_pnl"] > 0).mean()
}
print("\n=== Walkforward Summary ===")
print(pd.DataFrame([summary]).to_markdown(index=False))

# 3) 히스토그램
plt.figure()
plt.hist(df["test_pnl"], bins=20)
plt.title("Distribution of Test PnL per Window")
plt.xlabel("Test PnL")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

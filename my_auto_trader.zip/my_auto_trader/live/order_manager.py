# live/order_manager.py

import time
import math
from decimal import Decimal, ROUND_DOWN, getcontext
from pybit.unified_trading import HTTP

class OrderManager:
    """
    1) 분할 주문(지정가) + 시장가 전환(시간 초과)
    2) 주기적으로 가격 재조정(지능형 지정가)
    """
    def __init__(self, session: HTTP, reprice_interval=60, order_timeout=180):
        self.session= session
        self.reprice_interval= reprice_interval  # 재조정 주기 (초)
        self.order_timeout= order_timeout

        self.open_orders= {} 
        # { symbol: {
        #     "side": "Buy"/"Sell",
        #     "entry_price": float,
        #     "qty": float,
        #     "start_time": float,
        #     "last_reprice": float,
        #     "leverage": int,
        #     "splits": [1.0, 0.995],
        #     "remaining_qty": float
        #   }
        # }

    def place_smart_limit_order(self, symbol, side, price, qty, leverage, splits):
        """
        분할 주문 배치
        """
        import time
        now= time.time()
        total_qty= 0.0
        order_ids= []
        for i, rate in enumerate(splits):
            split_price= price* rate
            split_qty= qty/ len(splits)
            split_qty= round(split_qty, 4)
            try:
                resp= self.session.place_order(
                    category="linear",
                    symbol=symbol,
                    side= side,
                    order_type="Limit",
                    qty= str(split_qty),
                    price= f"{split_price:.4f}",
                    time_in_force="PostOnly",
                    reduce_only=False,
                    leverage= leverage
                )
                oid= resp["result"]["orderId"]
                order_ids.append(oid)
                total_qty+= split_qty
            except Exception as e:
                print("[place_smart_limit_order] 주문 실패:", e)
        if order_ids:
            self.open_orders[symbol]= {
                "side": side,
                "entry_price": price,
                "qty": total_qty,
                "start_time": now,
                "last_reprice": now,
                "leverage": leverage,
                "splits": splits,
                "order_ids": order_ids
            }

    def monitor_orders(self):
        """
        1) 부분 체결 확인
        2) 재조정(주기)
        3) 시간 초과 시 시장가
        """
        while True:
            now= time.time()
            for symbol in list(self.open_orders.keys()):
                data= self.open_orders[symbol]

                try:
                    open_info= self.session.get_open_orders(category="linear", symbol=symbol)
                    open_list= open_info["result"]["list"]
                except Exception as e:
                    print("[monitor_orders] 오류:", e)
                    continue

                # 누적체결량
                filled= 0.0
                for oid in data["order_ids"]:
                    match= [o for o in open_list if o["orderId"]== oid]
                    if match:
                        info= match[0]
                        cum_qty= float(info["cumExecQty"])
                        filled+= cum_qty

                # 만약 filled>= data["qty"] 이면 전부 체결
                if filled>= data["qty"]-1e-6:
                    print(f"[주문체결 완료] {symbol} side={data['side']} qty={data['qty']}")
                    del self.open_orders[symbol]
                    continue

                # 시간 초과 => 시장가 전환
                if now- data["start_time"]> self.order_timeout:
                    remain= data["qty"]- filled
                    if remain> 0:
                        try:
                            side= data["side"]
                            resp= self.session.place_order(
                                category="linear",
                                symbol=symbol,
                                side= side,
                                order_type="Market",
                                qty= str(round(remain,4)),
                                leverage= data["leverage"]
                            )
                            print(f"[시간초과 → 시장가] {symbol} remain={remain}")
                        except Exception as e:
                            print("[시장가 전환 오류]", e)
                    # 남은 주문 취소
                    for oid in data["order_ids"]:
                        try:
                            self.session.cancel_order(category="linear", symbol=symbol, order_id= oid)
                        except: pass
                    del self.open_orders[symbol]
                    continue

                # 재조정(주기)
                if now- data["last_reprice"]>= self.reprice_interval:
                    # 이미 채워진 양만큼은 제외
                    remain_qty= data["qty"]- filled
                    if remain_qty<=0:
                        del self.open_orders[symbol]
                        continue
                    # 남은 주문 취소
                    for oid in data["order_ids"]:
                        try:
                            self.session.cancel_order(category="linear", symbol=symbol, order_id=oid)
                        except: pass
                    # 새 지정가
                    side= data["side"]
                    new_price= data["entry_price"]
                    # 약간 더 유리하게 or 현재 호가 확인
                    # 생략: 호가조회해서 best bid/ask 근처로 배치
                    # 예시로 entry_price* (1- 0.0001) 등
                    if side=="Buy":
                        new_price*= 0.9998
                    else:
                        new_price*= 1.0002

                    remain_qty= round(remain_qty, 4)
                    # 재배치
                    data["order_ids"]= []
                    splits= data["splits"]
                    portion= remain_qty/ len(splits)
                    portion= round(portion,4)
                    for rt in splits:
                        p= new_price* rt
                        try:
                            r= self.session.place_order(
                                category="linear",
                                symbol=symbol,
                                side= side,
                                order_type="Limit",
                                qty= str(portion),
                                price= f"{p:.4f}",
                                time_in_force="PostOnly",
                                leverage= data["leverage"]
                            )
                            data["order_ids"].append(r["result"]["orderId"])
                        except Exception as e:
                            print("[재조정 주문 실패]", e)
                    data["last_reprice"]= now

            time.sleep(5)

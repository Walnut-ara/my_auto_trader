# live/portfolio_manager.py
import json

class PortfolioManager:
    def __init__(self, path="config/portfolio.json"):
        with open(path,"r",encoding="utf-8") as f:
            cfg= json.load(f)
        self.max_positions= cfg["max_positions"]
        self.daily_loss_limit= cfg["daily_loss_limit"]
        self.monthly_loss_limit= cfg["monthly_loss_limit"]
        self.priority_map= cfg.get("symbol_priority",{})
    
    def can_add_position(self, open_positions: dict, symbol: str) -> bool:
        """
        1) 동시 포지션 수>= max_positions => False
        2) 심볼 우선순위 체크 (예시: 이미 우선순위 높은 종목 차있으면?)
        """
        if len(open_positions)>= self.max_positions:
            # 추가로, symbol_priority 활용 가능
            return False
        return True
    
    def get_priority(self, symbol: str):
        return self.priority_map.get(symbol, 999)

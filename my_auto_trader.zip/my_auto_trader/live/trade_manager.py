# live/trade_manager.py
import os
import time
import json
import pandas as pd
from datetime import datetime
from pybit.unified_trading import HTTP
from strategy.base_strategy import compute_indicators
from strategy.strategy_manager import check_entry
from .order_manager import OrderManager
from .portfolio_manager import PortfolioManager

JSON_DIR= "json"
INVEST_USD= 10

class TradeManager:
    def __init__(self):
        self.session= HTTP() 
        # API_KEY, API_SECRET => .env or OS env
        self.order_mgr= OrderManager(self.session, reprice_interval=60, order_timeout=180)
        self.pf_mgr= PortfolioManager("config/portfolio.json")

        self.symbols= [f.replace(".json","") for f in os.listdir(JSON_DIR) if f.endswith(".json")]
        self.open_positions= {}
        self.daily_pnl= 0.0
        self.monthly_pnl= 0.0
        now= datetime.now()
        self.current_day= now.day
        self.current_month= now.month

    def update_pnl(self, realized_pnl):
        now= datetime.now()
        if now.day!= self.current_day:
            self.current_day= now.day
            self.daily_pnl= 0.0
        if now.month!= self.current_month:
            self.current_month= now.month
            self.monthly_pnl= 0.0

        self.daily_pnl+= realized_pnl
        self.monthly_pnl+= realized_pnl
        print(f"[PNL UPDATE] daily={self.daily_pnl:.2f}, monthly={self.monthly_pnl:.2f}")

    def can_trade_today(self):
        if self.daily_pnl<= self.pf_mgr.daily_loss_limit:
            return False
        if self.monthly_pnl<= self.pf_mgr.monthly_loss_limit:
            return False
        return True

    def load_config(self, sym):
        path= os.path.join(JSON_DIR, f"{sym}.json")
        with open(path,"r",encoding="utf-8") as f:
            return json.load(f)

    def run(self):
        # 주문 모니터링(부분체결, 재조정 등) 스레드
        import threading
        t= threading.Thread(target= self.order_mgr.monitor_orders, daemon=True)
        t.start()

        while True:
            if not self.can_trade_today():
                print("손실 제한 -> 대기")
                time.sleep(300)
                continue

            # 포지션 모니터링(간단. TP/SL or time exit)
            self.monitor_positions()

            for sym in self.symbols:
                if sym in self.open_positions:
                    continue
                # can_add_position
                if not self.pf_mgr.can_add_position(self.open_positions, sym):
                    continue

                cfg= self.load_config(sym)
                sym_cfg= cfg[sym]
                main_tf= sym_cfg.get("main_timeframe",15)
                kl= self.session.get_kline(category="linear", symbol=sym, interval=str(main_tf), limit=100)
                bars= kl["result"]["list"]
                if not bars:
                    continue
                df= pd.DataFrame(bars, columns=["ts","open","high","low","close","volume","turnover"])
                for c in ["open","high","low","close","volume"]:
                    df[c]= pd.to_numeric(df[c], errors="coerce")
                df["ts"]= pd.to_datetime(df["ts"].astype(float), unit="ms")
                df.set_index("ts", inplace=True)
                df.dropna(inplace=True)
                df= compute_indicators(df)
                if len(df)<2:
                    continue
                row= df.iloc[-1]
                prev= df.iloc[-2]

                ok, direction= check_entry(row, prev, sym_cfg, df.reset_index(), len(df)-1)
                if ok:
                    self.enter_position(sym, row["close"], direction, sym_cfg)

            time.sleep(30)

    def enter_position(self, symbol, close_price, direction, params):
        side= "Buy" if direction=="long" else "Sell"
        slip= params["risk"].get("slippage_rate",0.0005)
        base_entry= close_price*(1+ slip if direction=="long" else 1- slip)
        leverage= params["risk"].get("leverage",1)
        qty= (INVEST_USD* leverage)/ base_entry
        qty= round(qty,4)

        splits= params.get("entry_splits",[1.0])
        print(f"[분할주문] {symbol} side={side}, entry={base_entry:.4f}, qty={qty}, splits={splits}")
        self.order_mgr.place_smart_limit_order(symbol, side, base_entry, qty, leverage, splits)

    def monitor_positions(self):
        # 간단 예시. 실제론 TP/SL or 분할청산 etc. 
        # 여기서는 "수동청산"만 감지
        # => 만약 bybit에서 position size=0이면 실현손익 update
        for sym in list(self.open_positions.keys()):
            try:
                pos_info= self.session.get_positions(category="linear", symbol=sym)["result"]["list"][0]
                if float(pos_info["size"])==0:
                    print(f"[수동청산감지] {sym}")
                    del self.open_positions[sym]
            except:
                pass

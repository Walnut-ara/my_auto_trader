#!/usr/bin/env python3
# analysis_walkforward.py
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt

# 1) 워크포워드 결과 로드
df = pd.read_csv("walkforward_ADAUSDT.csv")

# 2) 요약 통계 계산
summary = {
    "Mean PnL": df["test_pnl"].mean(),
    "Median PnL": df["test_pnl"].median(),
    "Std PnL": df["test_pnl"].std(),
    "Max PnL": df["test_pnl"].max(),
    "Min PnL": df["test_pnl"].min(),
    "Win Rate": (df["test_pnl"] > 0).mean()
}
summary_df = pd.DataFrame([summary])
print("\n=== Walkforward Summary ===")
print(summary_df.to_markdown(index=False))

# 3) 테스트 PnL 분포 히스토그램
plt.figure()
plt.hist(df["test_pnl"], bins=20)
plt.title("Distribution of Test PnL per Window")
plt.xlabel("Test PnL")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# 4) 누적 PnL Equity Curve
df = df.reset_index().rename(columns={"index": "window_index"})
df["cum_pnl"] = df["test_pnl"].cumsum()

plt.figure()
plt.plot(df["window_index"], df["cum_pnl"])
plt.title("Cumulative Test PnL Over Windows")
plt.xlabel("Window Index")
plt.ylabel("Cumulative PnL")
plt.tight_layout()
plt.show()

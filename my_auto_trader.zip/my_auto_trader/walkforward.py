# walkforward.py

import os
import json
import pandas as pd
from datetime import datetime, timedelta
from strategy.base_strategy import compute_indicators
from backtest.backtest_runner import backtest_multitf, fetch_ohlcv


def run_walkforward(symbol, start_date, end_date, window, step, param_grid):
    """
    Walk-forward analysis:
      - symbol: 거래 심벌 (예: "ADAUSDT")
      - start_date, end_date: 문자열 "YYYY-MM-DD"
      - window: 학습 구간 기간(일)
      - step: 테스트 구간 기간(일)
      - param_grid: {'param1': [v1,v2], ...}
    """
    # 날짜 문자열 -> datetime
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end   = datetime.strptime(end_date, "%Y-%m-%d")

    # 전체 결과 저장
    all_results = []

    # 슬라이딩 윈도우 계산
    current_start = start
    while current_start + timedelta(days=window) <= end:
        train_start = current_start
        train_end   = current_start + timedelta(days=window)
        test_start  = train_end
        test_end    = train_end + timedelta(days=step)
        if test_end > end:
            test_end = end

        # 각 파라미터 조합 테스트
        for params in (dict(zip(param_grid, v)) for v in pd.MultiIndex.from_product(param_grid.values())):
            # 데이터 로드 및 지표 계산
            df = fetch_ohlcv(symbol, train_start, test_end)
            df = compute_indicators(df)

            # Train/Validation backtest
            # backtest_multitf는 ((train_pnl, train_trades), (test_pnl, test_trades)) 반환
            (train_pnl, train_trades), (test_pnl, test_trades) = backtest_multitf(
                df,
                symbol=symbol,
                sl_mult=params.get("sl_mult", 1.0),
                tp_mult=params.get("tp_mult", 1.0),
                rsi_threshold=params.get("rsi_threshold", 30),
                fee=0.0004,
                slippage=0.0002
            )

            # 결과 기록
            all_results.append({
                "train_start":      train_start.strftime("%Y-%m-%d"),
                "train_end":        train_end.strftime("%Y-%m-%d"),
                "test_start":       test_start.strftime("%Y-%m-%d"),
                "test_end":         test_end.strftime("%Y-%m-%d"),
                "train_pnl":        round(train_pnl, 2),
                "test_pnl":         round(test_pnl, 2),
                "train_trades":     train_trades,
                "test_trades":      test_trades,
                "avg_pnl_trade":    round((test_pnl / test_trades) if test_trades > 0 else 0.0, 4),
                **params
            })

        # 다음 윈도우 시작 위치
        current_start += timedelta(days=step)

    # DataFrame 생성 및 저장
    results_df = pd.DataFrame(all_results)
    csv_path   = f"walkforward_{symbol}.csv"
    results_df.to_csv(csv_path, index=False)
    print(f"[워크포워드 완료] {csv_path}")
    return results_df


# 예시 직접 호출
if __name__ == "__main__":
    run_walkforward(
        symbol="ADAUSDT",
        start_date="2025-01-01",
        end_date="2025-05-31",
        window=60,
        step=15,
        param_grid={
            "rsi_threshold": [10, 20, 30, 40],
            "sl_mult": [0.5, 1.0, 1.5],
            "tp_mult": [1.0, 2.0, 3.0]
        }
    )

#!/usr/bin/env python3
"""
optuna_walkforward.py
Walk-forward + Optuna 최적화를 CSV 파일을 읽어서 수행하는 스크립트
"""

import optuna
import pandas as pd
from walkforward import run_walkforward

# ── 설정 영역 ───────────────────────────────────────────────────────────────
SYMBOL     = "ADAUSDT"
START_DATE = "2025-01-01"
END_DATE   = "2025-05-31"
WINDOW     = 60
STEP       = 15
N_TRIALS   = 50
# ───────────────────────────────────────────────────────────────────────────

def objective(trial):
    # 1) 파라미터 제안
    rsi_th  = trial.suggest_int("rsi_threshold", 10, 50, step=5)
    sl_mult = trial.suggest_float("sl_mult", 0.5, 2.0, step=0.1)
    tp_mult = trial.suggest_float("tp_mult", 1.0, 5.0, step=0.5)

    # 2) 워크포워드 실행 (CSV로만 결과 저장)
    run_walkforward(
        symbol=SYMBOL,
        start_date=START_DATE,
        end_date=END_DATE,
        window=WINDOW,
        step=STEP,
        param_grid={
            "rsi_threshold": [rsi_th],
            "sl_mult":       [sl_mult],
            "tp_mult":       [tp_mult],
        }
    )

    # 3) 방금 저장된 CSV 읽기
    csv_path = f"walkforward_{SYMBOL}.csv"
    df = pd.read_csv(csv_path)

    # 4) 평가 지표: test_pnl 평균
    return df["test_pnl"].astype(float).mean()

def main():
    # Optuna 로그 레벨 조정 (선택)
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=N_TRIALS)

    print("🔍 Best parameters:", study.best_params)
    print("🏆 Best avg test PnL:", study.best_value)

if __name__ == "__main__":
    main()

# trend_strategy.py
from .base_strategy import calc_fee, volume_filter

def check_trend_entry(row, prev, params, df, idx):
    """
    row: df.iloc[idx]
    prev: df.iloc[idx-1]
    params: json dict
    returns (True/False, direction)
    """
    # trend_filter
    if row["ema50"]<= row["ema200"]:
        return (False, None)
    # adx_min
    adx_min= params["entry_conditions"].get("adx_min", None)
    if adx_min and row["adx"]< adx_min:
        return (False, None)
    # rsi_threshold
    rsi_th= params["entry_conditions"].get("rsi_threshold", 30)
    if row["rsi"]< rsi_th:
        # volume 필터
        vol_ratio= params["entry_conditions"].get("volume_filter",1.0)
        if not volume_filter(df, idx, vol_ratio):
            return (False, None)
        return (True, "long")
    return (False, None)

"""
strategy_manager.py

- 실제 진입 조건을 체크하는 로직
- 5가지 개선사항 중 일부 (RSI 반복 진입 차단, 볼륨 필터 등)
"""

def check_entry(row, prev, params, df, idx):
    """
    return (bool, direction)
      - bool: 진입여부
      - direction: "long"/"short"/None
    """
    entry_cond = params.get("entry_conditions", {})
    rsi_th = entry_cond.get("rsi_threshold", 30)
    adx_min = entry_cond.get("adx_min", 20)
    volume_filter_ratio = entry_cond.get("volume_filter_ratio", 1.0)

    # 현재 row에서 rsi, adx
    rsi_now = row.get("rsi", 50)
    adx_now = row.get("adx", 20)
    
    # 1) RSI 반복 진입 차단 예시:
    if idx >= 1:
        rsi_prev = df.iloc[idx-1].get("rsi", 50)
        if rsi_now < rsi_th and rsi_prev < rsi_th:
            return (False, None)
    
    # 2) ADX 필터
    if adx_now < adx_min:
        return (False, None)
    
    # 3) 거래량 필터(최근 20봉 평균 대비 x배)
    if "volume" in df.columns and idx >= 20 and volume_filter_ratio > 1.0:
        recent_vol = df["volume"].iloc[idx-20: idx].mean()
        if row["volume"] < recent_vol * volume_filter_ratio:
            return (False, None)
    
    # - 여기서는 간단하게 전부 long
    # 실제론 MACD나 등등 다른 조건도 추가 가능
    return (True, "long")

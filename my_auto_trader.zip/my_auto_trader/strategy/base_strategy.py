"""
base_strategy.py

- talib 대신 ta 라이브러리 사용
- RSI / ATR / ADX 등을 이 파일에서 계산
"""

import pandas as pd
import ta

def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    # copy 해서 안전하게 처리
    df = df.copy()
    # RSI
    df["rsi"] = ta.momentum.RSIIndicator(df["close"], window=14).rsi()
    # ATR
    df["atr"] = ta.volatility.AverageTrueRange(
        high=df["high"],
        low=df["low"],
        close=df["close"],
        window=14
    ).average_true_range()
    # ADX
    df["adx"] = ta.trend.ADXIndicator(
        high=df["high"],
        low=df["low"],
        close=df["close"],
        window=14
    ).adx()
    
    df.dropna(inplace=True)
    return df


def calc_fee(raw_pct: float, fee_cfg: dict) -> float:
    """
    단순 메커니즘:
      - maker/taker 혼합 수수료 고려
      - 총 round trip
    """
    maker_fee = fee_cfg.get("maker_fee", 0.0001)
    taker_fee = fee_cfg.get("taker_fee", 0.0006)
    maker_ratio = fee_cfg.get("expected_maker_ratio", 0.5)

    # 평균 fee%
    mean_fee = maker_fee * maker_ratio + taker_fee * (1 - maker_ratio)
    # *2 => 진입 + 청산 수수료
    net_pct = raw_pct - (mean_fee * 2 * 100)
    return net_pct

# strategy/market_condition.py

def detect_market_condition(df, lookback=20, adx_threshold=25, skip_threshold=15):
    """
    최근 lookback 봉의 평균 ADX를 통해 시장 상태 분류:
      - 평균 ADX >= adx_threshold -> 'trend'
      - adx_threshold > 평균 ADX >= skip_threshold -> 'range'
      - 평균 ADX < skip_threshold -> 'skip' (매매 회피)
    """
    if len(df) < lookback:
        # 데이터가 충분치 않으면 'trend'로 가정
        return "trend"

    recent = df.iloc[-lookback:]
    avg_adx = recent["adx"].mean()

    if avg_adx < skip_threshold:
        return "skip"
    elif avg_adx < adx_threshold:
        return "range"
    else:
        return "trend"

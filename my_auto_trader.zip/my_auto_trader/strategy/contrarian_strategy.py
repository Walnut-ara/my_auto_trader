# contrarian_strategy.py
from .base_strategy import calc_fee, volume_filter

def check_contrarian_entry(row, prev, params, df, idx):
    """
    예: ema50<ema200, rsi>70 or 볼린저 상단 이탈 => 숏
    """
    if row["ema50"]> row["ema200"]:
        return (False, None)
    adx_min= params["entry_conditions"].get("adx_min", None)
    if adx_min and row["adx"]> adx_min:
        # adx가 높으면 추세장 -> 역추세 안 함
        return (False,None)

    rsi_th= params["entry_conditions"].get("rsi_threshold",70)
    if row["rsi"]> rsi_th:
        vol_ratio= params["entry_conditions"].get("volume_filter",1.0)
        if not volume_filter(df, idx, vol_ratio):
            return (False,None)
        return (True, "short")
    return (False, None)

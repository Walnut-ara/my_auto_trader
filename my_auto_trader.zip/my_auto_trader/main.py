"""
main.py

- 진입점: python main.py --sim 2025.05
- 인자:
   --sim YYYY.MM : 특정 연/월 백테스트 실행
   --wf          : 워크 포워드 테스트 실행
"""

import sys
import argparse
from backtest.backtest_runner import run_simulation
from walkforward import run_walkforward

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sim", type=str, default=None, help="예) 2025.05")
    parser.add_argument("--wf", action="store_true", help="워크포워드 테스트 실행")
    args = parser.parse_args()

    if args.sim:
        run_simulation(args.sim)
    elif args.wf:
        # 예시
        run_walkforward("BTCUSDT", start_date="2024-01-01", end_date="2024-12-31")
    else:
        print("인자 없음: --sim YYYY.MM 혹은 --wf 를 지정해주세요.")

if __name__ == "__main__":
    main()

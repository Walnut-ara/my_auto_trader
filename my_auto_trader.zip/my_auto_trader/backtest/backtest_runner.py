"""
backtest_runner.py

- 백테스트 실행부
- 5가지 개선사항 모두 적용
   (1) RSI 반복 진입
   (2) sl_mult=0.7 등 손절 축소
   (3) 조기 청산(2봉)
   (4) 거래량 필터
   (5) 트레이드 로그 자동 저장
"""

import os
import json
import pandas as pd
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

from pybit.unified_trading import HTTP
from strategy.base_strategy import compute_indicators, calc_fee
from strategy.strategy_manager import check_entry

CACHE_DIR = "cache"
JSON_DIR = "json"

INVEST_USD = 10
MAX_LOSSES = 6

def fetch_ohlcv(session, symbol, since, until, tf, label):
    """
    - Bybit Kline (unified) 호출해서 ohlcv 가져오고, CSV 캐싱
    - 'volume' 필드가 존재
    """
    import os
    import pandas as pd

    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_path = f"{CACHE_DIR}/ohlcv_{symbol}_{tf}_{label}.csv"
    if os.path.exists(cache_path):
        df = pd.read_csv(cache_path, index_col="ts", parse_dates=True)
        # volume parse
        for c in ["open","high","low","close","volume"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df.dropna(inplace=True)
        return df

    data = []
    start_ts = since
    seen_ts = set()

    for _ in range(1000):
        resp = session.get_kline(
            category="linear",
            symbol=symbol,
            interval=str(tf),
            limit=1000,
            start=start_ts
        )
        bars = resp.get("result", {}).get("list", [])
        if not bars:
            break
        for b in bars:
            ts = float(b[0])  # ms
            if ts >= until:
                break
            if ts not in seen_ts:
                # b = [ts, open, high, low, close, volume, turnover]
                data.append([ts]+b[1:6]) 
                seen_ts.add(ts)
        last_ts = float(bars[-1][0])
        start_ts = last_ts + tf * 60 * 1000
        if last_ts >= until or len(bars) < 1000:
            break
    
    df = pd.DataFrame(data, columns=["ts","open","high","low","close","volume"])
    df["ts"] = pd.to_datetime(df["ts"], unit="ms")
    df.set_index("ts", inplace=True)
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df.dropna(inplace=True)
    df.to_csv(cache_path)
    return df


def backtest_multitf(df, params,
                     invest_usd=10, max_losses=6,
                     label="202505",
                     symbol="???"):
    """
    - 분할청산, ATR 트레일링, ADX, volume filter 등
    - 개선 사항:
      (2) sl_mult=0.7 등으로 축소
      (3) 조기청산 2봉 후 exit
      (5) trade_logs
    """
    df = df.reset_index().copy()
    df_len = len(df)
    # 기본값 세팅
    fee_cfg = params.get("risk", {})
    fee_cfg.setdefault("leverage", 1)
    fee_cfg.setdefault("maker_fee", 0.0001)
    fee_cfg.setdefault("taker_fee", 0.0006)
    fee_cfg.setdefault("expected_maker_ratio", 0.5)
    
    slip = fee_cfg.get("slippage_rate", 0.0005)
    # 손절 / 익절
    sl_mult = params.get("sl_mult", 0.7)  # 축소
    tp_mult = params.get("tp_mult", 1.5)
    
    # 기타
    use_trail = params.get("use_trailing_stop", False)
    trail_mult = params.get("trailing_atr_mult", 2.0)
    time_exit_bars = 2  # (3) 2봉 뒤 조기청산

    trades_list = []
    pnl = 0.0
    trades = 0
    losses = 0
    i = 200
    
    while i < df_len - 1:
        row = df.iloc[i]
        prev = df.iloc[i-1]
        ok, direction = check_entry(row, prev, params, df, i)
        if ok:
            # 진입
            entry_price = row["close"] * (1+slip if direction=="long" else 1-slip)
            atr_val = row["atr"]
            
            if direction=="long":
                stop_price = entry_price - atr_val * sl_mult
            else:
                stop_price = entry_price + atr_val * sl_mult
            
            remain_pos = 1.0
            trade_pnl = 0.0
            j = i + 1
            entry_ts = row["ts"]
            
            while j < df_len:
                cur = df.iloc[j]
                highp = cur["high"]
                lowp = cur["low"]
                
                if direction=="long":
                    # SL
                    if lowp <= stop_price:
                        sub_pct = ((stop_price - entry_price)/entry_price)*100
                        net_pct = calc_fee(sub_pct, fee_cfg)
                        sub_pnl = net_pct/100* invest_usd* fee_cfg["leverage"] * remain_pos
                        trade_pnl += sub_pnl
                        
                        # 로그
                        trades_list.append({
                            "ts_open": entry_ts,
                            "ts_close": cur["ts"],
                            "direction": "long",
                            "entry_price": entry_price,
                            "exit_price": stop_price,
                            "reason": "SL",
                            "raw_pct": sub_pct,
                            "net_pct": net_pct,
                            "pnl": sub_pnl
                        })
                        
                        remain_pos = 0
                        break
                    
                    # 추후 TP 분할청산을 단순화
                    # (필요 시 구현)
                    
                    # 트레일링
                    if use_trail and remain_pos>0:
                        new_stop = highp - (atr_val * trail_mult)
                        if new_stop > stop_price:
                            stop_price = new_stop
                
                else:
                    # short
                    if highp >= stop_price:
                        sub_pct = ((entry_price - stop_price)/ entry_price)*100
                        net_pct = calc_fee(sub_pct, fee_cfg)
                        sub_pnl = net_pct/100 * invest_usd* fee_cfg["leverage"] * remain_pos
                        trade_pnl += sub_pnl
                        
                        trades_list.append({
                            "ts_open": entry_ts,
                            "ts_close": cur["ts"],
                            "direction": "short",
                            "entry_price": entry_price,
                            "exit_price": stop_price,
                            "reason": "SL",
                            "raw_pct": sub_pct,
                            "net_pct": net_pct,
                            "pnl": sub_pnl
                        })
                        
                        remain_pos = 0
                        break
                    
                    # (TP 분할청산은 필요시 구현)

                    # trail
                    if use_trail and remain_pos > 0:
                        new_stop = lowp + (atr_val * trail_mult)
                        if new_stop < stop_price:
                            stop_price = new_stop
                
                # (3) 조기청산 - 2봉이 지남
                if (j - i) >= time_exit_bars:
                    # 강제 청산
                    lastp = df.iloc[j]["close"]
                    if direction=="long":
                        raw_pct = ((lastp - entry_price)/entry_price)*100
                    else:
                        raw_pct = ((entry_price - lastp)/entry_price)*100
                    net_pct = calc_fee(raw_pct, fee_cfg)
                    sub_pnl = net_pct/100 * invest_usd* fee_cfg["leverage"]* remain_pos
                    trade_pnl += sub_pnl
                    
                    trades_list.append({
                        "ts_open": entry_ts,
                        "ts_close": cur["ts"],
                        "direction": direction,
                        "entry_price": entry_price,
                        "exit_price": lastp,
                        "reason": "time_exit",
                        "raw_pct": raw_pct,
                        "net_pct": net_pct,
                        "pnl": sub_pnl
                    })
                    
                    remain_pos = 0
                    break
                
                if remain_pos <= 0:
                    break
                j += 1
            
            if remain_pos > 0:
                # 포지션이 남아있다면 마지막 close로
                lastp = df.iloc[min(j, df_len-1)]["close"]
                if direction=="long":
                    raw_pct = ((lastp - entry_price)/ entry_price)*100
                else:
                    raw_pct = ((entry_price - lastp)/ entry_price)*100
                net_pct = calc_fee(raw_pct, fee_cfg)
                sub_pnl = net_pct/100 * invest_usd* fee_cfg["leverage"]* remain_pos
                trade_pnl += sub_pnl
                
                trades_list.append({
                    "ts_open": entry_ts,
                    "ts_close": df.iloc[min(j, df_len-1)]["ts"],
                    "direction": direction,
                    "entry_price": entry_price,
                    "exit_price": lastp,
                    "reason": "final_exit",
                    "raw_pct": raw_pct,
                    "net_pct": net_pct,
                    "pnl": sub_pnl
                })
                
                remain_pos = 0
            
            trades += 1
            pnl += trade_pnl
            if trade_pnl < 0:
                losses += 1
            if losses >= max_losses:
                print(f"[백테스트] 연속 손실 {max_losses} 회 초과 -> 중단")
                break
            i = j
        else:
            i += 1
    
    # 로그 CSV 저장
    logs_df = pd.DataFrame(trades_list)
    if not logs_df.empty:
        outfn = f"trade_logs_{symbol}_{label}.csv"
        logs_df.to_csv(outfn, index=False)
    
    return round(pnl, 2), trades


def run_simulation(sim_month="2025.05"):
    """
    특정 월(YYYY.MM)에 대해 JSON_DIR 폴더내 symbol 리스트 불러서 백테스트
    """
    session = HTTP()
    y,m = map(int, sim_month.split("."))
    start = datetime(y,m,1)
    end = (start+timedelta(days=32)).replace(day=1)
    since = int(start.timestamp()*1000)
    until = int(end.timestamp()*1000)
    label = start.strftime("%Y%m")
    
    # json 폴더
    symbols = [f.replace(".json","") for f in os.listdir(JSON_DIR) if f.endswith(".json")]
    results = []
    
    def simulate_symbol(sym):
        try:
            cfg_path = os.path.join(JSON_DIR, f"{sym}.json")
            cfg = json.load(open(cfg_path, "r", encoding="utf-8"))
            params = cfg[sym]
            
            # 여러 TF?
            tf_list = params.get("timeframes", [params.get("main_timeframe", 15)])
            df_map = {}
            for tf in tf_list:
                df1 = fetch_ohlcv(session, sym, since, until, tf, label)
                df1 = compute_indicators(df1)
                df_map[tf] = df1
            
            main_tf = params["main_timeframe"]
            df_main = df_map[main_tf]
            
            p, t = backtest_multitf(
                df_main, params,
                invest_usd=INVEST_USD,
                max_losses=MAX_LOSSES,
                label=label,
                symbol=sym
            )
            return {"symbol": sym, "net_profit": p, "trades": t}
        except Exception as e:
            return {"symbol": sym, "net_profit": "ERR", "trades": 0, "error": str(e)}
    
    # 병렬 처리
    with ThreadPoolExecutor() as exc:
        futs = [exc.submit(simulate_symbol, s) for s in symbols]
        for f in as_completed(futs):
            r = f.result()
            print("[백테스트]", r)
            results.append(r)
    
    # 결과 정리
    df_res = pd.DataFrame(results)
    out_name = f"simulated_summary_{label}.csv"
    df_res.to_csv(out_name, index=False)
    print("[백테스트 완료]", out_name)

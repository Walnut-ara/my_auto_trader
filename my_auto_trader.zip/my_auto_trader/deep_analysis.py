#!/usr/bin/env python3
# deep_analysis.py
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt

# ── 1) CSV 로드 & 컬럼 확인 ────────────────────────
csv_path = "walkforward_ADAUSDT.csv"
df = pd.read_csv(csv_path)
print("▶ Columns:", df.columns.tolist(), "\n")
print(f"▶ Loaded {len(df)} windows\n")

# ── 2) Test PnL 기본 통계 & 분포 ─────────────────
print("=== Test PnL Summary ===")
print(df["test_pnl"].describe().to_frame().T, "\n")

plt.figure()
plt.hist(df["test_pnl"], bins=20)
plt.title("Test PnL Distribution")
plt.xlabel("PnL")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# 누적 PnL 커브
df = df.reset_index().rename(columns={"index":"window"})
df["cum_pnl"] = df["test_pnl"].cumsum()
plt.figure()
plt.plot(df["window"], df["cum_pnl"], marker="o")
plt.title("Cumulative Test PnL")
plt.xlabel("Window")
plt.ylabel("Cumulative PnL")
plt.tight_layout()
plt.show()

# ── 3) Trades & Avg-PnL per Trade ─────────────────
if "trades" in df.columns:
    # 기존 trades 컬럼을 test_trades로 간주
    df = df.rename(columns={"trades": "test_trades"})
    # 0거래 방지
    df["avg_pnl_trade"] = df.apply(
        lambda r: (r.test_pnl / r.test_trades) if r.test_trades > 0 else 0.0,
        axis=1
    )

    print("=== Trades & Avg-PnL per Trade ===")
    print(df[["test_trades","avg_pnl_trade"]].describe(), "\n")

    # 거래 횟수 분포
    plt.figure()
    plt.hist(df["test_trades"], bins=range(int(df["test_trades"].max())+2))
    plt.title("Trades per Window")
    plt.xlabel("Number of Trades")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.show()

    # per-trade PnL 분포
    plt.figure()
    plt.hist(df["avg_pnl_trade"], bins=20)
    plt.title("Avg PnL per Trade")
    plt.xlabel("PnL/Trade")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.show()

    zero_pct = (df["test_trades"] == 0).mean()
    print(f"▶ Windows with zero trades: {zero_pct:.0%}\n")

else:
    print("⚠️ 'trades' 컬럼이 없습니다. walkforward.py 쪽에서 거래 횟수를 기록하도록 패치해 주세요.")
